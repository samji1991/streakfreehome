=== AllStore ===

Contributors: automattic
Tags: translation-ready, custom-background, theme-options, custom-menu, post-formats, threaded-comments

Requires at least: 4.0
Tested up to: 4.5.3
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WordPress 4.0+ Ready

WordPress 3+ Custom Menu Support

Responsive design

Blog post layout changing – for each page you can choose between:

Easy logo replacement

Sociable Icons section in footer and Social widget

SEO Ready

Contact form validator

Comments with reply functionality (multiple levels depth)

Works and looks similar in all major browsers: Internet Explorer, Firefox, Opera, Safari, Google Chrome

Documentation included

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

