<?php
if (function_exists('woocommerce_breadcrumb')) {
    woocommerce_breadcrumb();
}